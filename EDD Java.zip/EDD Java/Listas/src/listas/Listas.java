/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listas;

import java.util.ArrayList; //agregada para trabaja arreglos
import java.util.List;  //libreria importada para utilizar el elemento List

/**
 *
 * @author aleja
 */
public class Listas {

    public static void main(String[] args) {
        List<Integer> Numeros;
        
        Numeros = new ArrayList<>();
        
        //agregar un numero
        Numeros.add(13);
        Numeros.add(143);
        Numeros.add(431);
        Numeros.add(341);
        Numeros.add(61);
        Numeros.add(1765);
        Numeros.add(417);
        
        //Imprimir nuemro
        System.out.println(Numeros.get(0));
        
        //Elimiar un numero
        Numeros.remove(0);
    }
    
}
