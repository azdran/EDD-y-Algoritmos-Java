/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilasmemoriadinamica;

/**
 *
 * @author aleja
 */
public class NodoPila {
    int dato;
    NodoPila siguiente;
    
    //Método Constructor
    public NodoPila(int d){
        dato=d;
        siguiente=null;
    }
    
}
