/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilasmemoriadinamica;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class PilasMemoriaDinamica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion = 0, elemento = 0;
        Pila pilita = new Pila();
        do {
            opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "1. Empujar Elemento en la Pila\n"
                    + "2. Sacar un elemento de la Pila\n"
                    + "3. ¿La Pila está Vacía?\n"
                    + "4. ¿Que Elemento está en la Cima?\n"
                    + "5. Tamaño de la Pila\n"
                    + "6. Vaciar Pila\n"
                    + "7. Salir\n"
                    + "¿Que Deseas Hacer?", "                ====== MENU DE OPCIONES =======",
                    JOptionPane.INFORMATION_MESSAGE));
            switch (opcion) {
                case 1:
                    elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa el elemento que quieres empujar a la Pila", "Apilando Datos en la pila",
                            JOptionPane.INFORMATION_MESSAGE));
                   pilita.empujar(elemento);
                    break;
                case 2:
                    if (!pilita.estaVacia()) {
                        JOptionPane.showMessageDialog(null, "El Elemento Obtenido es: " + pilita.sacar(),
                                "Obteiendo Datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "La pila Esta Vacía",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                case 3:
                    if (pilita.estaVacia()) {
                        JOptionPane.showMessageDialog(null, "La Pila Está Vacia",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "La pila NO está vacía",
                                "La pila Contiene Datos", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                case 4:
                    if (!pilita.estaVacia()) {
                        JOptionPane.showMessageDialog(null, "El elemento que se encuentra en la cima es: " + pilita.cima(),
                                "Cima de la Pila", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(null, "La Pila Está Vacia",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                    }
                    break;
                case 5:
                    JOptionPane.showMessageDialog(null, "El Tamaño de la pila es; " +pilita.tamañoPila(),
                                "Tamaño de la Pila", JOptionPane.INFORMATION_MESSAGE);

                    break;
                case 6:
                    if(!pilita.estaVacia()){
                        pilita.limpiar();
                        JOptionPane.showMessageDialog(null, "La Pila se ha Vaciado ",
                            "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                    }else{
                        JOptionPane.showMessageDialog(null, "La Pila Está Vacia, No hay nada que vaciar",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                    }
                    
                    break;
                case 7:
                    JOptionPane.showMessageDialog(null, "Aplicacion Finalizada",
                            "Fin", JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción Incorreta!",
                            "Error!", JOptionPane.INFORMATION_MESSAGE);
            }

        } while (opcion != 7);
        try {
        } catch (NumberFormatException n) {
            JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
        }
    }
    
    
}
  