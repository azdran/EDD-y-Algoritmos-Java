/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilasmemoriadinamica;

/**
 *
 * @author aleja
 */
public class Pila {
    private NodoPila cima;
    int tamaño;
    
    //Método constructor
    public Pila(){
        cima=null;
        tamaño=0;
    }
    
    //Método para saber Cúanlo la pil esta vacía
    public boolean estaVacia(){
        return cima==null;
    }
    
    //Metodo push(Para empujar un numero en la pila)
    public void empujar(int elem){
        NodoPila nuevo=new NodoPila(elem);
        nuevo.siguiente=cima;
        cima=nuevo;
        tamaño++;
    }
    
    //Metodo POP (Sacar un elemento de la pila)
    public int sacar(){
        int auxiliar =cima.dato;
        cima=cima.siguiente;
        tamaño--;
        return auxiliar;
    }
    
    //Metodo para saber quien esta en la Cima de la Pila
    public int cima(){
        return cima.dato;
    }
    
    //Método para saber el tamaño de la pila
    public int tamañoPila(){
        return tamaño;
    }
    
    //Método para limpiar la pila
    public void limpiar(){
        while(!estaVacia()){
            sacar();
        }
    }
}
