/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilasmemoriaestatica;

/**
 *
 * @author aleja
 */
public class Pila {
    int vectorPila[];
    int cima; //almacenara el ultimo dato
    
    //Método Constructor de la Clase
    public Pila(int tamaño){
        vectorPila=new int [tamaño];
        cima = -1;
    }
    
    //Método push (Empluja un elemento en la pila)
    public void empujar(int dato){
        cima++;
        vectorPila[cima]=dato;
    }
    
    //Método pop
    public int sacar(){
        int fuera=vectorPila[cima];
        cima--;
        return fuera;
    }
    
    //Método para saber si la pila esta Vacía
    public boolean estaVacia(){
        return cima==-1;
    }
    
    //Método para saber si la pila está Llena
    public boolean estaLlena(){
        return vectorPila.length-1==cima; 
    }
    
    //Método para saber que elemento se encuentra en la cima
    public int cimaPila(){
        return vectorPila[cima];
    }
    
    //Método para saber el tamaño de la pila 
    public int tamañoPila(){
        return vectorPila.length;
    }
    
}
