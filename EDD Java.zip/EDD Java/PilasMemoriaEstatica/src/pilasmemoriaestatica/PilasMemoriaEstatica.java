/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pilasmemoriaestatica;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class PilasMemoriaEstatica {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion = 0, elemento, tamaño;
        boolean estado=false;
        try {
            tamaño = Integer.parseInt(JOptionPane.showInputDialog(null,
                    "¿De que Tamaño quieres la pila?", "Soliitando Tamño de Pila",
                    JOptionPane.INFORMATION_MESSAGE));
            Pila pilita = new Pila(tamaño);
            do {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Empujar Elemento en la Pila\n"
                        + "2. Sacar un elemento de la Pila\n"
                        + "3. ¿La Pila está Vacía?\n"
                        + "4. ¿La Pila está Llena?\n"
                        + "5. ¿Que Elemento está en la Cima?\n"
                        + "6. Tamaño de la Pila\n"       
                        + "7. Salir\n"
                        + "¿Que Deseas Hacer?", "                ====== MENU DE OPCIONES =======",
                        JOptionPane.INFORMATION_MESSAGE));
                switch (opcion) {
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el elemento que quieres empujar a la Pila", "Apilando Datos en la pila",
                                JOptionPane.INFORMATION_MESSAGE));
                        if(!pilita.estaLlena()){
                            pilita.empujar(elemento);
                        }else{
                            JOptionPane.showMessageDialog(null, "La Pila Esta Llena",
                                "Pila Llena", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 2:
                        if(!pilita.estaVacia()){
                            JOptionPane.showMessageDialog(null, "El Elemento Obtenido es: " + pilita.sacar(),
                                "Obteiendo Datos de la Pila", JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La pila Esta Vacía",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3:
                        if(pilita.estaVacia()){
                            JOptionPane.showMessageDialog(null, "La Pila Está Vacia",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La pila NO está vacía",
                                "La pila Contiene Datos", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 4:
                        if(pilita.estaLlena()){
                            JOptionPane.showMessageDialog(null, "La Pila Está Llena",
                                "Pila Llena", JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La pila NO está Llena",
                                "La pila Contiene Espacio aún", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 5:
                        if(!pilita.estaVacia()){
                              JOptionPane.showMessageDialog(null, "El elemento que se encuentra en la cima es: " + pilita.cimaPila(),
                                "Cima de la Pila", JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La Pila Está Vacia",
                                "Pila Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }
                      
                        break;
                    case 6:
                        JOptionPane.showMessageDialog(null, "El tamaño de la pila es: " + pilita.tamañoPila(),
                                "Tamaño de Pila", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, "Aplicacion Finalizada",
                                "Fin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción Incorreta!",
                                "Error!", JOptionPane.INFORMATION_MESSAGE);
                }

            } while (opcion != 7);
        } catch (NumberFormatException n) {
            JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
        }
    }

}
