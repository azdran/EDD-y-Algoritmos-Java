/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class Colas {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int opcion = 0, elemento = 0;
        Cola colita = new Cola();

        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Insertat un Elemento de la COla\n"
                        + "2. Quitar un Elemento de la Cola\n"
                        + "3. ¿La Cola Está Vacía?\n"
                        + "4. ¿Elemento Ubicado al Inicio de la Cola?\n"
                        + "5. Tamaño de la cola\n"
                        + "6. Salir", "   ===== Menu de Opiones de na Cola ======", JOptionPane.QUESTION_MESSAGE));

                switch (opcion) {
                    case 1: //Insertr un elemento en la cola
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el elemento a Insertar", "insertando en la Cola",
                                JOptionPane.INFORMATION_MESSAGE));
                        colita.insertar(elemento);
                        break;
                    case 2://Quitar un Elemento de la Cola
                        if(!colita.estaVacia()){
                            JOptionPane.showMessageDialog(null, "El elemento atendido es: " +colita.quitar(),
                                    "Quitando Elementos de la Cola",JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La Cola estáVacía ",
                                    "Cola Vacía",JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3://¿La cola esta Vacía?
                        if(colita.estaVacia()){
                            JOptionPane.showMessageDialog(null, "La Cola está Vacía ",
                                    "Cola Vacía",JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La Cola No está Vacía ",
                                    "Cola No Vacía",JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 4://Elemento ubicado al inicio de la Cola
                        if(!colita.estaVacia()){
                            JOptionPane.showMessageDialog(null, "El Elemento ubicado al inicio de la cola es:  " + colita.inicioCola(),
                                    "Inicio de Cola",JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "La Cola está Vacía ",
                                    "Cola Vacía",JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 5: //Tamaño de la Cola
                        JOptionPane.showMessageDialog(null, "El Tamaño de la Cola es: "+ colita.tamaño,
                                    "Tamaño de la Cola",JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 6://Salir
                        JOptionPane.showMessageDialog(null, "Aplicación Finalizada ",
                                    "Fin",JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción Incorrecta ",
                                    "¡CUIDADO!",JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (NumberFormatException n) {
                JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
            }
        } while (opcion != 6);
    }

}
