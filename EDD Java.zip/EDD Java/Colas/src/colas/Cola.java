/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package colas;

/**
 *
 * @author aleja
 */
public class Cola {
    NodoCola inicio,fin;
    int tamaño;
    
    //constructor
    public Cola(){
        inicio=fin=null;
        tamaño=0;
    }
    
    //Método para saber si esta vacia la COla
    public boolean estaVacia(){
        return inicio==null;
    }
    
    //Método para Inertar
    public void insertar(int ele){
        NodoCola nuevo=new NodoCola(ele);
        if(estaVacia()){
            inicio=nuevo;
        }else{
            fin.siguiente=nuevo;
        }
        fin=nuevo;
        tamaño++;
    }
    //Método para quitar elemento de la cola
    public int quitar(){
        int aux =inicio.dato;
        inicio=inicio.siguiente;
        tamaño--;
        return aux;
    }
    //Método para saber quien esta al inicio de la cola
    public int inicioCola(){
        return inicio.dato;
    }
    
    //Método para saber el tamaño e la cola
    public int tamañoCola(){
        return tamaño;
    }
}

