/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasimplementeenlazada;

/**
 *
 * @author aleja
 */
public class Lista {
    
    //creacion de 2 puteros 
    protected  Nodo inicio, fin; //punteros para saber donde esta el iniio y el fin
    
    //Constructor iniciliza los punteros
    public Lista(){
        inicio = null;
        fin = null; 
    }
    
     //Método para saber si la lista esta vacia
    public boolean estaVacia(){
        if(inicio == null){
            return true;
        }
        else{
            return false;
        }
    }
    
    //Método para  Agregar un nodo al Iicio de la lista (Recibe como parametro el elemento de la lista)
    public void agregarAlInicio(int elemento){
        //Creando al nodo
        inicio = new Nodo(elemento, inicio);
        if (fin == null){
            fin=inicio;
        }
    }   
    
   //Método para insertar al final de la lista
    public void agregarAlFinal(int elemento){
        if(!estaVacia()){
                fin.siguiente=new Nodo(elemento);
                fin = fin.siguiente;
        }
        else{
            inicio = fin = new Nodo(elemento);
        }
    }
    
    
    //Método para mostrar los datos
    
    public void mostrarLista(){
        Nodo recorrer = inicio;
        System.out.println();
        while(recorrer!=null){
            System.out.print("["+recorrer.dato+"]--->");
            recorrer = recorrer.siguiente;
        }
    }
    //Método para borar un nodo del inicio
    public int borrarDelInicio(){
        int elemento = inicio.dato;
        if(inicio==fin){
            inicio=null;
            fin=null;
        }else{
            inicio=inicio.siguiente;
        }
        return elemento;
    }
    
    //Método para eliminar un Nodo del Final
    public int borrarDelFinal(){
        int elemento = fin.dato;
        if(inicio == fin){
            inicio = fin = null;
        }
        else{
            Nodo temporal = inicio;
            while(temporal.siguiente!=fin){
                temporal=temporal.siguiente;
            }
            fin = temporal;
            fin.siguiente = null;
        }
        return elemento;
    }
    
    //Método para eliminar un Nodo Especifico
    public void eliminar(int elemento){
        if(!estaVacia()){
            if(inicio==fin && elemento==inicio.dato){ // se declara si cuando es el primer elemento
                inicio = fin = null; //hace que inicio y fin apunten a null
            }
            else if(elemento==inicio.dato){
                inicio = inicio.siguiente;
            }else{
                Nodo anterior, temporal;
                anterior = inicio;
                temporal = inicio.siguiente;
                while(temporal!=null && temporal.dato!=elemento){
                    anterior=anterior.siguiente;
                    temporal = temporal.siguiente;
                }
                if (temporal!=null){
                    anterior.siguiente = temporal.siguiente;
                    if(temporal==fin){
                        fin=anterior;
                    }
                }
            }
        }
    }
    
    //Método para buscar un elemento
    public boolean estaEnLaLista(int elemento){
        Nodo temporal = inicio;
        while(temporal!=null && temporal.dato!=elemento){
            temporal = temporal.siguiente;
        }
        return temporal!=null;
    }
}
