/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasimplementeenlazada;

/**
 *
 * @author aleja
 */
public class Nodo {
    //Delcarar dato
    public int dato;
    public Nodo siguiente; //Punero enlace
   
    //Constructor para insertar al Final
    public Nodo(int d){
        this.dato = d;
        this.siguiente=null;
    }
     //contructor para inserta un elemento al inicio de la lista
    public Nodo(int d, Nodo n){
        dato=d;
        siguiente=n;
    }
   
}
