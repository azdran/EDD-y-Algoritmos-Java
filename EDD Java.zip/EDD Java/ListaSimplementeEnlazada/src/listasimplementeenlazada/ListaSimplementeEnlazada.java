/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listasimplementeenlazada;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class ListaSimplementeEnlazada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
       //crea Objeto
        Lista listita = new Lista();
        //Declaracion de Variale 
        int opcion = 0, el;
        do{
            try{
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null, 
                        "1. Agregar un Elemento al inicio de la lista\n2. Agregar un Elemento al Final de la Lista\n"
                                + "3. Motrar los datos de la lista\n"
                                + "4. Eliminar un Elemento del Inicio de la Lista\n"
                                + "5. Eliminar un Elemento del Final de la Lista\n"
                                + "6. Eliminar un Elemento en Especifico\n" 
                                + "7. Buscar un Elemento en la Lista\n"
                                + "8. Salir", "       === MENU DE OPCIONES ===",3));
                switch(opcion){
                    case 1:
                        try{
                            el = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el Elemento:",
                                    "Insertando al Inicio",3));
                                
                               //Agregando al nodo
                            listita.agregarAlInicio(el);
                        }catch(NumberFormatException n){
                        JOptionPane.showMessageDialog(null, "Error "+ n.getMessage());
                            }
                        break;
                    case 2:
                        try{
                            el = Integer.parseInt(JOptionPane.showInputDialog(null,"Ingresa el Elemento:",
                                    "Insertando al Inicio",3));
                                
                               //Agregando al nodo
                            listita.agregarAlFinal(el);
                        }catch(NumberFormatException n){
                        JOptionPane.showMessageDialog(null, "Error "+ n.getMessage());
                            }
                        
                        break;
                    case 3:
                        listita.mostrarLista();
                        break;
                    case 4:
                        el = listita.borrarDelInicio();
                        JOptionPane.showMessageDialog(null, "El Elemeno Eliminado es: " +el,
                                "Eliminando Nodo del Inicio", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    case 5:
                        el = listita.borrarDelFinal();
                        JOptionPane.showMessageDialog(null, "El Elemeno Eliminado es: " +el,
                                "Eliminando Nodo del Final", JOptionPane.INFORMATION_MESSAGE);
                      break;
                    case 6:
                        el = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa el "
                                + "Elemento a Eliminar","Eliminando Nodo en Especifico", JOptionPane.INFORMATION_MESSAGE));
                        if(listita.estaEnLaLista(el)){
                            listita.eliminar(el);
                            JOptionPane.showMessageDialog(null, "El Elemeno Eliminado es: " +el,
                                "Eliminando Nodo en Especifico", JOptionPane.INFORMATION_MESSAGE);
                        }else{
                            JOptionPane.showMessageDialog(null, "El Elemeno : " +el+" No está en la lista",
                                "Nodo NO Encontrado", JOptionPane.INFORMATION_MESSAGE);
                        }
                        
                        break;
                    case 7:
                        el = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingresa el "
                                + "Elemento a Buscar","Buscando Nodo en la Lista", JOptionPane.INFORMATION_MESSAGE));
                        if(listita.estaEnLaLista(el)==true){
                            JOptionPane.showMessageDialog(null, "El elemento:  " + el + "  Si está en la lista",
                                     "Nodo encontrado", JOptionPane.INFORMATION_MESSAGE);
                            
                        }else{
                            JOptionPane.showMessageDialog(null, "El elemento: " + el + " No está en la lista",
                                     "Nodo No Encontrado", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 8:
                        JOptionPane.showMessageDialog(null, "Programa Finalizado ");
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opcion Incorrecta ");
                }
                
                
            }catch(Exception e){
                JOptionPane.showMessageDialog(null, "Error "+ e.getMessage());
        }
        }while(opcion!=8);
    }
    
}
