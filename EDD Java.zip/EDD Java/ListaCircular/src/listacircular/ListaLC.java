/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listacircular;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class ListaLC {
    NodoLC ultimo;
    
    public ListaLC(){
        ultimo=null; //Inicia en nulo porque al iniio no tenemos nada    
    }
    
    //Método Cuando la lista esta vacía
    public boolean estaVacia(){
        return ultimo==null;
    }
    
    //Método para insertar Nodos
    public ListaLC insertar(int elemento){
        NodoLC nuevo = new NodoLC(elemento);
        if(ultimo!=null){ //si ulimo es diferente de Null quiere decir que ya hay un nodo
            nuevo.siguiente=ultimo.siguiente;
            ultimo.siguiente=nuevo;
        }
        ultimo=nuevo;
        return this;
    }
      
      
    //Método para mostrar la Lista
    public void mostarLista(){
        NodoLC auxiliar = ultimo.siguiente;
        String cadena ="";
        do{
            cadena = cadena + "["+auxiliar.dato+"]->"; //concatena lo que sacamos de auxiliar de dato
            auxiliar=auxiliar.siguiente;
        }while(auxiliar!=ultimo.siguiente);
        JOptionPane.showMessageDialog(null,  cadena, "Mostrando la Lista circular",
                JOptionPane.INFORMATION_MESSAGE);
    }
    
    //Método para eliminar un NODO de la LISTA CIRCULAR
    public boolean eliminar(int elemento){
        NodoLC actual;
        boolean encontrado = false;
        actual=ultimo;
        while(actual.siguiente!=ultimo && !encontrado){
            encontrado=(actual.siguiente.dato==elemento);
            if(!encontrado){
                actual=actual.siguiente;
            }
    }
        encontrado=(actual.siguiente.dato==elemento);
        if(encontrado == true){
            NodoLC auxiliar=actual.siguiente;
            if(ultimo==ultimo.siguiente){
                ultimo=null;
            }else{
                if(auxiliar==ultimo){
                    ultimo=actual;
                }
                actual.siguiente=auxiliar.siguiente;
            }
            auxiliar=null;
        }
        return encontrado==true;
    }
}
