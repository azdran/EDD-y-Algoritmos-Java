/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listacircular;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class ListaCircular {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ListaLC listita = new ListaLC();
        //variables
        int opcion = 0, elemento;
        boolean eliminado = false;
        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Agregar Un Nodo a la Lista Circular\n"
                        + "2. Eliminar un Nodo de la Lista Circular\n"
                        + "3. Motrar los datos de la lista circular\n"
                        + "4. Salir\n"
                        + "¿Que deseas Hacer?", "           ===== MENU DE OPCIONES=====",
                        JOptionPane.INFORMATION_MESSAGE));
                switch (opcion) {
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el elemento del Nodo", "Agregando Nodo a la lista circular",
                                JOptionPane.INFORMATION_MESSAGE));
                        listita.insertar(elemento);
                        break;
                    case 2:
                        if(!listita.estaVacia()){
                         elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el elemento del Nodo a Eliminar", "Eliminando Nodo de la lista circular",
                                JOptionPane.INFORMATION_MESSAGE));
                         eliminado = listita.eliminar(elemento);
                         if(eliminado==true){
                             JOptionPane.showMessageDialog(null, "El elemento eliminado es: " + elemento ,
                                "Eliminando Nodos", JOptionPane.INFORMATION_MESSAGE);
                         }
                         else{
                             JOptionPane.showMessageDialog(null, "El elemento: " + elemento + " No está en la lista", 
                                "Elemento NO enontrado", JOptionPane.INFORMATION_MESSAGE);
                            }
                        } else{
                            JOptionPane.showMessageDialog(null, "Aun No hay Nodos",
                                "Lista Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }  
                        break;
                    case 3:
                        if(!listita.estaVacia()){
                           listita.mostarLista();
                       }else{
                            JOptionPane.showMessageDialog(null, "Aun No hay Nodos",
                                "Lista Vacía", JOptionPane.INFORMATION_MESSAGE);
                       }
                        
                        break;
                    case 4:
                        JOptionPane.showMessageDialog(null, "Aplicación Finalizada",
                                "Fiiin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "La Opción No está en el MENU",
                                "Incorrecto", JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (NumberFormatException n) {
                JOptionPane.showMessageDialog(null, "Error " + n.getMessage());
            }
        } while (opcion != 4);
    }
    
}
