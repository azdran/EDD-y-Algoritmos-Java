/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listacircular;

/**
 *
 * @author aleja
 */
public class NodoLC {
    // crear atributo tipo entero
    int dato;
    NodoLC siguiente; //crea un puntero de la clase NodoLC
    
    //Constructor para inicializar (Recibe un dato y lo inicializa)
    public NodoLC(int d){
        dato=d;
        siguiente=this; //apunta al mismo nodo
    }
}
