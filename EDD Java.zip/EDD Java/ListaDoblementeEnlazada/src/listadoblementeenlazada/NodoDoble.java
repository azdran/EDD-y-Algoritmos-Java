/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadoblementeenlazada;

/**
 *
 * @author aleja
 */
public class NodoDoble {

    // crear dato entero
    public int dato;

    //crear punteros
    NodoDoble siguiente, anterior;

    //Constructor para cuando aun No hay nodos
    public NodoDoble(int el) {
        this(el, null, null);  //Crea nodo implementando consructor 
    }

    //Constructor para cuando ya hay nodos
    public NodoDoble(int el, NodoDoble s, NodoDoble a) {
        //inicilizar variables
        dato = el;
        siguiente = s;
        anterior = a;
    }

}
