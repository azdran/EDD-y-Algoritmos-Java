/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listadoblementeenlazada;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class ListaDoblementeEnlazada {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ListaDoble listita = new ListaDoble();
        //variables
        int opcion = 0, elemento;
        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Agregar Un Nodo al Inicio\n"
                        + "2. Agregar un Nodo al Final\n"
                        + "3. Motrar la lista de Inicio a Fin\n"
                        + "4. Mostrar la lista de Fin a Inicio\n"
                        + "5. Eliminar un Nodo del Inicio\n"
                        + "6. Eliminar un Nodo del Final\n"
                        + "7. Salir\n"
                        + "¿Que deseas Hacer?", "           ===== MENU DE OPCIONES=====",
                        JOptionPane.INFORMATION_MESSAGE));
                switch (opcion) {
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el elemento del Nodo", "Agregando Nodo al Inicio",
                                JOptionPane.INFORMATION_MESSAGE));
                        listita.agregarAlInicio(elemento);
                        break;
                    case 2:

                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el elemento del Nodo", "Agregando Nodo al Final",
                                JOptionPane.INFORMATION_MESSAGE));
                        listita.agregarAlFinal(elemento);
                        break;
                    case 3:
                        if (!listita.estaVacia()) {
                            listita.mostrarListaInicioFin();
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay Nodos Aun",
                                    "Lista Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 4:
                        if (!listita.estaVacia()) {
                            listita.mostrarListaFinInicio();
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay Nodos Aun",
                                    "Lista Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 5:
                        if (!listita.estaVacia()) {
                            elemento = listita.eliminarDeInicio();
                            JOptionPane.showMessageDialog(null, "El elemento eliminado es: " + elemento,
                                    "Eliminando Nodo del Inicio", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay Nodos Aun",
                                    "Lista Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 6:
                        if (!listita.estaVacia()) {
                            elemento = listita.eliminarDeFinal();
                            JOptionPane.showMessageDialog(null, "El elemento eliminado es: " + elemento,
                                    "Eliminando Nodo del Final", JOptionPane.INFORMATION_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null, "No hay Nodos Aun",
                                    "Lista Vacía", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, "Aplicación Finalizada",
                                "Fiiin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "La Opción No está en el MENU",
                                "Incorrecto", JOptionPane.INFORMATION_MESSAGE);
                }

            } catch (NumberFormatException n) {
                JOptionPane.showMessageDialog(null, "Error " + n.getMessage());
            }
        } while (opcion != 7);
    }

}
