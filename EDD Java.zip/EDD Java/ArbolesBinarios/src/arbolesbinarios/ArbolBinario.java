/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolesbinarios;

/**
 *
 * @author aleja
 */
public class ArbolBinario {
    NodoArbol raiz; 
    
    //Método constructor
    public ArbolBinario(){
        raiz = null; //iniciañiza la raiz en nulo.
    }
    
    //Método para insertar un nodo en el arbol
    public void agregarNodo(int d, String nom){
        NodoArbol nuevo = new NodoArbol(d, nom);
        if(raiz==null){
        raiz=nuevo;
    }else{
        NodoArbol auxiliar = raiz;
        NodoArbol padre;
        while(true){
            padre=auxiliar;
            if(d<auxiliar.dato){ //para el caso de que d sea menor que dato
                auxiliar=auxiliar.hijoIzquierdo;
                if(auxiliar==null){
                    padre.hijoIzquierdo = nuevo;
                    return; // un simple return sirve para finalizar la ejecucion de un método
                }
            }else // entonces es mayor o igual entonces debe de insertarse a la derecha
            {
                auxiliar=auxiliar.hijoDerecho;
                if(auxiliar==null){
                    padre.hijoDerecho=nuevo;
                    return;
                }
            }
        }
      }
    }
     //Método para saber cuando un arbol esta vacio
    public boolean estaVacio(){
        return raiz==null;
    }
    //Método para recorrer un árbol InOrden
    public void inOrden(NodoArbol r){
        if(r!=null){
            inOrden(r.hijoIzquierdo);
            System.out.print(r.dato + ", ");
            inOrden(r.hijoDerecho);
        }
    }
    
     //Método para recorrer un árbol PreOrden
    public void preOrden(NodoArbol r){
        if(r!=null){
            System.out.print(r.dato + ", ");
            preOrden(r.hijoIzquierdo);
            preOrden(r.hijoDerecho);
        }
    }
    
     //Método para recorrer un árbol PostOrden
    public void postOrden(NodoArbol r){
        if(r!=null){
           
            postOrden(r.hijoIzquierdo);
            postOrden(r.hijoDerecho);
            System.out.print(r.dato + ", ");
        }
    }
    
    //Método para encontrar un Nodo en el Árbol
    public NodoArbol buscarNodo(int d){
        NodoArbol aux=raiz;
        while(aux.dato!=d){
            if(d<aux.dato){
                aux=aux.hijoIzquierdo;
            }else{
                aux=aux.hijoDerecho;
            }
            if(aux==null){
                return null;
            }
        }
        return aux;
    }
    
    //Método para Eliminar un Nodo del Arbol
    public boolean eliminar(int d){
        NodoArbol auxiliar=raiz;
        NodoArbol padre=raiz;
        boolean esHijoIzq=true;
        
        while(auxiliar.dato!=d){ //busca el nodo a eliminar para ver si existe
            padre=auxiliar;
            if(d<auxiliar.dato){ //quiere decir que se tiene que ir por la izquierda
                esHijoIzq=true;
                auxiliar=auxiliar.hijoIzquierdo; //apuntamos auziliar a la izquierda
            }else{
                esHijoIzq=false;
                auxiliar=auxiliar.hijoDerecho; //
            }
            if(auxiliar==null){
                return false; //quiere decir que llego al final del arbol y no encontro el nodo
            }
        }//fin del while
        
        if(auxiliar.hijoIzquierdo==null && auxiliar.hijoDerecho==null){ //quiere decir que es Hoja o la raiz
            if(auxiliar==raiz){//quiere decir que es la raiz
                raiz=null;
            }else if(esHijoIzq){
                padre.hijoIzquierdo=null;
                }else {
                    padre.hijoDerecho=null;
                }
            }else if(auxiliar.hijoDerecho==null){
                if(auxiliar==raiz){//quiere decir que es la raiz
                    raiz=auxiliar.hijoIzquierdo;
                }else
                if(esHijoIzq){
                    padre.hijoIzquierdo=auxiliar.hijoIzquierdo;
                }else{
                    padre.hijoDerecho=auxiliar.hijoIzquierdo;
                }                
            }else if(auxiliar.hijoIzquierdo==null){
                if(auxiliar==raiz){//quiere decir que es la raiz
                    raiz=auxiliar.hijoDerecho;
                }else
                if(esHijoIzq){
                    padre.hijoIzquierdo=auxiliar.hijoDerecho;
                }else{
                    padre.hijoDerecho=auxiliar.hijoIzquierdo;
                }  
            }else{
                NodoArbol reemplazo=obtenerNodoReemplazo(auxiliar);
                if(auxiliar==raiz){
                    raiz=reemplazo;
                }else if(esHijoIzq){
                    padre.hijoIzquierdo=reemplazo;
                }else{
                    padre.hijoDerecho=reemplazo;
                }
                reemplazo.hijoIzquierdo=auxiliar.hijoIzquierdo;
            }
        return true;//si llaga hasta este punto quiere decir que si ecnontro y reemplazó el nodo
        }
    
    //Método encargado de devolvernos el Nodo Reemplazo
    public NodoArbol obtenerNodoReemplazo(NodoArbol nodoReem){
        NodoArbol reemplazarPadre=nodoReem;
        NodoArbol reemplazo=nodoReem;
        NodoArbol auxiliar=nodoReem.hijoDerecho;
        
        while(auxiliar!=null){ //recorremos para saber cual nodo se va a reemplazar
            reemplazarPadre=reemplazo;
            reemplazo=auxiliar;
            auxiliar=auxiliar.hijoIzquierdo;
        }
        if(reemplazo!=nodoReem.hijoDerecho){
            reemplazarPadre.hijoIzquierdo=reemplazo.hijoDerecho;
            reemplazo.hijoDerecho=nodoReem.hijoDerecho;
        }
        System.out.println("El Nodo Reemplazo es: " + reemplazo);
        return reemplazo;
    }
}//fin de clase main
