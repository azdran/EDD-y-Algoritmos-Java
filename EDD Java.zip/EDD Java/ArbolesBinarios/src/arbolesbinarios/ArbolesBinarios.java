/*Esta apliacion esta eleborada a partir de un tutorial que obtuve en Youtube
34.- Árboles binarios de Búsqueda, Creación e Inserción (EDDJava).

Link: https://www.youtube.com/watch?v=ZKnwBJ8q2TE&ab_channel=MasterHeHeGar
 */
package arbolesbinarios;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class ArbolesBinarios {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
        // TODO code application logic here
        int opcion = 0, elemento;
        String nombre;
        ArbolBinario arbolito = new ArbolBinario();
        do {
            try {
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Agregar Nodo\n"
                      + "2. Recorrer InOrden\n"
                      + "3. Recorrer PreOrden\n"
                      + "4. Recorrido PostOrden\n"
                      + "5. Buscar un Nodo\n"
                      + "6. Eliminar\n"
                      + "7. Salir\n"
                      + "Elige Una Opción...", "Árboles Binarios",
                        JOptionPane.QUESTION_MESSAGE));
                switch (opcion) {
                    case 1:
                        elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el Numero del Nodo...", "Agregando Nodo",
                                JOptionPane.QUESTION_MESSAGE));
                        nombre = JOptionPane.showInputDialog(null,
                                "Ingresa el nombre del Nodo...", "Agregando Nodo",
                                JOptionPane.QUESTION_MESSAGE);
                        arbolito.agregarNodo(elemento, nombre);
                        break;
                    case 2:
                        if(!arbolito.estaVacio()){
                            System.err.println();
                            arbolito.inOrden(arbolito.raiz);
                        }else{
                            JOptionPane.showMessageDialog(null, "El Árbol Esta Vacío",
                                "¡CUIDADO!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 3:
                        if(!arbolito.estaVacio()){
                            System.err.println();
                            arbolito.preOrden(arbolito.raiz);
                        }else{
                            JOptionPane.showMessageDialog(null, "El Árbol Esta Vacío",
                                "¡CUIDADO!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 4:
                        if(!arbolito.estaVacio()){
                            System.err.println();
                            arbolito.postOrden(arbolito.raiz);
                        }else{
                            JOptionPane.showMessageDialog(null, "El Árbol Esta Vacío",
                                "¡CUIDADO!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 5:
                        if(!arbolito.estaVacio()){
                            elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el Número del Nodo a Buscar...", "Buscando Nodo",
                                JOptionPane.QUESTION_MESSAGE));
                            arbolito.buscarNodo(elemento);
                            if(arbolito.buscarNodo(elemento)==null){
                                JOptionPane.showMessageDialog(null, "El Nodo no se encuentra en el Árbol",
                                "Nodo NO Encontrado", JOptionPane.INFORMATION_MESSAGE);
                            }else{
                                System.out.println("Nodo Encontrado, sus datos son:  Nombre:  " + arbolito.buscarNodo(elemento));
                            }
                        }else{
                            JOptionPane.showMessageDialog(null, "El Árbol Esta Vacío",
                                "¡CUIDADO!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 6:
                        if(!arbolito.estaVacio()){
                            elemento = Integer.parseInt(JOptionPane.showInputDialog(null,
                                "Ingresa el Número del Nodo a Eliminar...", "Eliminando Nodo",
                                JOptionPane.QUESTION_MESSAGE));
                            
                            if(arbolito.eliminar(elemento)==false){
                                JOptionPane.showMessageDialog(null, "El Nodono se encuentra en el Árbol",
                                "Nodo NO Encontrado", JOptionPane.INFORMATION_MESSAGE);
                            }else{
                                JOptionPane.showMessageDialog(null, "El Nodo ha sido eliminado del Árbol",
                                "Nodo Eliminado", JOptionPane.INFORMATION_MESSAGE);
                            }
                            }else{
                            JOptionPane.showMessageDialog(null, "El Árbol Esta Vacío",
                                "¡CUIDADO!", JOptionPane.INFORMATION_MESSAGE);
                        }
                        break;
                    case 7:
                        JOptionPane.showMessageDialog(null, "Aplicación Finalizada",
                                "Fin", JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción Incorrecta",
                                "Error", JOptionPane.INFORMATION_MESSAGE);
                }
                }catch(NumberFormatException n) {
                    JOptionPane.showMessageDialog(null, "Error" + n.getMessage());                        
                }
            }while (opcion != 7);
    }
   
        
}//Final de la clase


