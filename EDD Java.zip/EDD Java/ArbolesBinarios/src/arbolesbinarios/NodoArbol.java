/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arbolesbinarios;

/**
 *
 * @author aleja
 */
public class NodoArbol {
    int dato;
    String nombre;
    NodoArbol hijoIzquierdo;
    NodoArbol hijoDerecho;
    
    //Método Constructor crear el NodoArbol
    public NodoArbol(int d, String nom){
        this.dato=d;
        this.nombre=nom;
        this.hijoIzquierdo = null;
        this.hijoDerecho=null;
    }
    
    //método permite mostrar la informacion completa del objeto, el valor de todos sus atributos
    public String toString(){
        return nombre + " Su dato es: " + dato; //regresa el nombre y concatena su respectivo dato.
    }
}
