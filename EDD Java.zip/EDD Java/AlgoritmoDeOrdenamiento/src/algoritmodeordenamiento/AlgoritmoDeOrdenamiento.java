/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritmodeordenamiento;
    
import javax.swing.JOptionPane;

public class AlgoritmoDeOrdenamiento{
   
    public static void main(String[] args) {
       AlgoritmosDeOrdenamiento ordenar=new AlgoritmosDeOrdenamiento();
       int opcion = 0;
       //int [] vector;
        do{
            //opcion = Integer.parseInt(JOptionPane.showInputDialog(null,"Elige una Opcion para ordenar el Arreglo"));
            try{
                opcion = Integer.parseInt(JOptionPane.showInputDialog(null,
                        "1. Ordenar por Método Burbuja \n"
                        + "2. Ordenar por Método Burbuja V2 \n"
                        + "3. Ordenar por Método Radix \n"
                        + "4. Ordenar por Método Quick \n"
                        + "5. Ordenar por Método Inserción \n"
                        + "6. Ordenar por Método Shell\n"
                        + "7. Ordenar por Método Intercalación\n"
                        + "8. Ordenar por Método Mezcal Directa\n"
                        + "9. Salir\n"
                        + "Elige Una Opcion: ", " ==== .::Algoritmos de Ordenamiento::. ======", JOptionPane.QUESTION_MESSAGE));
                  
                switch(opcion){
                    case 1:
                            int tam;
                            tam = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                            int vector[] = new int[tam];
                            for(int i=0;i<tam;i++){
                            vector[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                        //Llamar al método
                         System.out.println("Arreglo Original");
                         ordenar.mostrarArreglo(vector);
                         ordenar.burbuja(vector);
                         System.out.println("Arreglo Ordenado con metodo Burbuja");
                         ordenar.mostrarArreglo(vector);
                        
                        break;
                    case 2:
                         int tam2;
                            tam2= Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                            int vector2[] = new int[tam2];
                            for(int i=0;i<tam2;i++){
                            vector2[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                        //Llamar al método
                         System.out.println("Arreglo Original");
                         ordenar.mostrarArreglo(vector2);
                         ordenar.burbuja2(vector2);
                         System.out.println("Arreglo Ordenado con Método Burbuja V2");
                         ordenar.mostrarArreglo(vector2);
                        break;
                    case 3:
                            int tam3;
                            tam3 = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                            int vector3[] = new int[tam3];
                            for(int i=0;i<tam3;i++){
                            vector3[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                         System.out.println("Arreglo Original");
                         ordenar.mostrarArreglo(vector3);
                         ordenar.Radix(vector3);
                         //System.out.println("Arreglo Ordenado con Método Radix");
                         //ordenar.mostrarArreglo(vector3);
                        break;
                    case 4:
                        int tam4;
                            tam4 = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                            int vector4[] = new int[tam4];
                            for(int i=0;i<tam4;i++){
                            vector4[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                         System.out.println("Arreglo Original");
                         ordenar.mostrarArreglo(vector4);
                         ordenar.Quick(vector4, 0, vector4.length-1);
                         System.out.println("Arreglo Ordenado por Método Quick");
                         ordenar.mostrarArreglo(vector4);
                         break;
                    case 5:
                        int tam5;
                        tam5 = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                        int vector5[] = new int[tam5];
                        for(int i=0;i<tam5;i++){
                        vector5[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                        "Ingresa El elemento del Indice "+ i));
                        
                        ordenar.insercion(vector5, i+1);
                        }
                        break;
                    case 6:
                        int tam6;
                            tam6 = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                            int vector6[] = new int[tam6];
                            for(int i=0;i<tam6;i++){
                            vector6[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                        //Llamar al método
                         System.out.println("Arreglo Original");
                         ordenar.mostrarArreglo(vector6);
                         ordenar.shell(vector6);
                         
                        break;
                    case 7:
                        int tam7;
                            tam7 = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del primer arreglo?"));
                            int vector7[] = new int[tam7];
                            for(int i=0;i<tam7;i++){
                            vector7[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                        int tam7a;
                            tam7a = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del segundo arreglo?"));
                            int vector7a[] = new int[tam7a];
                            for(int i=0;i<tam7a;i++){
                            vector7a[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }    
                        //Llamar al método
                         System.out.println("Primer Arreglo Original");
                         ordenar.mostrarArreglo(vector7);
                         System.out.println("Segundo Arreglo Original");
                         ordenar.mostrarArreglo(vector7a);
                         ordenar.burbuja(vector7);
                         ordenar.burbuja(vector7a);
                         ordenar.intercalacion(vector7, vector7a);
                        break;
                    case 8:
                        int tam8;
                            tam8 = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
                            int vector8[] = new int[tam8];
                            for(int i=0;i<tam8;i++){
                            vector8[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                            "Ingresa El elemento del Indice "+ i));
                            }
                        //Llamar al método
                         System.out.println("Arreglo Original");
                         ordenar.mostrarArreglo(vector8);
                         System.out.println("Arreglo Ordenado con metodo Mezcla Directa");
                         vector8=ordenar.mezclaDirecta(vector8);
                         ordenar.mostrarArreglo(vector8);
                        break;
                    case 9://Salir
                        JOptionPane.showMessageDialog(null, "Aplicación Finalizada ",
                                    "Fin",JOptionPane.INFORMATION_MESSAGE);
                        break;
                    default:
                        JOptionPane.showMessageDialog(null, "Opción Incorrecta ",
                                    "¡CUIDADO!",JOptionPane.INFORMATION_MESSAGE);
                }
            }catch(NumberFormatException n) {
                JOptionPane.showMessageDialog(null, "Error" + n.getMessage());
            }//fin de CATCH
        }while(opcion!=9);
                
    }   
       
       
       /*int tam;
        tam = Integer.parseInt(JOptionPane.showInputDialog("Cual es el tamaño del arreglo?"));
       int vector[] = new int[tam];
       for(int i=0;i<tam;i++){
           vector[i]=Integer.parseInt(JOptionPane.showInputDialog(null,
                   "Ingresa El elemento del Indice "+ i));
           ordenar.insercion(vector, i+1);
           
       }*/
        int vector2[] ={51, 8, 11, 58, 63, 29, 27};
       int vector3[] ={5, 2, 1, 8, 3, 9, 7};
       /* System.out.println("Arreglo Original");
        ordenar.mostrarArreglo(vector1);
        
        System.out.println("Arreglo Ordenado");
        ordenar.burbuja(vector1);
        ordenar.mostrarArreglo(vector1);*/
       //System.out.println("Arreglo Original");
       //ordenar.mostrarArreglo(vector1);
       //ordenar.mostrarArreglo(vector3);
       //System.out.println("Arreglo Ordenado con Quick");
       //ordenar.Quick(vector3, 0, vector3.length-1);
      //System.out.println("Arreglo Originel");
      //ordenar.mostrarArreglo(vector3);
     // ordenar.shell(vector3);
     
     /*System.out.println("Arreglo vector3 Original");
     ordenar.mostrarArreglo(vector2);
     System.out.println("Arreglo vector2 Original");
     ordenar.mostrarArreglo(vector3);
     ordenar.Radix(vector2);
     ordenar.Radix(vector3);
     ordenar.intercalacion(vector2, vector3);*/
     
   /*System.out.println("Arreglo Vector2 Original");
   ordenar.mostrarArreglo(vector2);
   System.out.println("Arreglo vector2 Ordenado por Mezcla Directa");
   vector2=ordenar.mezclaDirecta(vector2);//almacena el vector ya ordenado
   ordenar.mostrarArreglo(vector2);//imprime el vector ya ordenado
   */
        
    
      
    
}
