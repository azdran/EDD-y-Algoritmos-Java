/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algoritmodeordenamiento;

import javax.swing.JOptionPane;

/**
 *
 * @author aleja
 */
public class AlgoritmosDeOrdenamiento {

    int i, j, temporal;
    public AlgoritmosDeOrdenamiento(){
        this.i=0;
        this.j=0;
        this.temporal=0;
    }
    
    //Método Burbuja version 1

    /**
     *
     * @param arreglo
     */
    public void burbuja(int [] arreglo){
        for(i=0;i<arreglo.length;i++){
            for(j=i+1;j<arreglo.length;j++){
                if(arreglo[i]>arreglo[j]){
                    temporal=arreglo[i];
                    arreglo[i]=arreglo[j];
                    arreglo[j]=temporal;
                }
            }
        }
    }
    
    //Metodo Burbuja Version 2
    public void burbuja2(int [] arreglo){
        for(i=1;i<arreglo.length;i++){
            for(j=0;j<arreglo.length-1;j++){
                if(arreglo[j]>arreglo[j+1]){
                    temporal=arreglo[j];
                    arreglo[j]=arreglo[j+1];
                    arreglo[j+1]=temporal;
                }
            }
        }
    }
    
    
    //Metodo Radix
    public void Radix(int [] arreglo){
        int x,i,j;
        for(x=Integer.SIZE-1;x>0;x--){
            int auxiliar[]=new int[arreglo.length];
            j=0;
            for(i=0;i<arreglo.length;i++){
                boolean mover=arreglo[i]<< x >=0;
                if(x==0 ? !mover:mover){
                    auxiliar[j]=arreglo[i];
                    j++;
                }else{
                    arreglo[i-j]=arreglo[i];
                }
            }
            for(i=j;i<auxiliar.length;i++){
                auxiliar[i]=arreglo[i-j];
        }
        arreglo=auxiliar;
        
        }
        System.out.println("El arreglo Ordenado con Radix es: ");
        mostrarArreglo(arreglo);
    }
    
    //Método Quick
    public void Quick(int [] arreglo, int primero, int ultimo){
        int i,j,pivote,auxiliar;
        i=primero;
        j=ultimo;
        pivote=arreglo[(primero+ultimo)/2];
        System.out.println("el pivote es: "+pivote);
        do{
            while(arreglo[i]<pivote){
                i++;
            }
            while(arreglo[j]>pivote){
                j--;
            }
            //aqui hacemos el intercambio
            if(i<=j){
                auxiliar=arreglo[i];
                arreglo[i]=arreglo[j];
                arreglo[j]=auxiliar;
                i++;
                j--;
            }
        }while(i<=j);
        if(primero<j){
            Quick(arreglo, primero, j);
            
        }
        if(i<ultimo){
            Quick(arreglo, i, ultimo);
        }
        mostrarArreglo(arreglo);
    }
    
    //Método para Insercion
    public void insercion(int [] arreglo, int n){
        int i,j, auxiliar;
        for(i=1;i<n;i++){
            auxiliar=arreglo[i];
            j=i-1;
            while(j>=0 && arreglo[j]>auxiliar){
                arreglo[j+1]=arreglo[j];
                j=j-1;
            }
            arreglo[j+1]=auxiliar;
        }
        System.out.println("Arreglo Ordenado por Insercion: ");
        mostrarArreglo(arreglo);
    }
    
    //Método Shell
    public void shell(int [] arreglo){
        int salto, i, j, k, auxiliar;
        salto=arreglo.length/2;
        while(salto>0){
            for(i=salto;i<arreglo.length;i++){
                j=i-salto;
                while(j>=0){
                    k=j+salto;
                    if(arreglo[j]<=arreglo[k]){
                        j=-1;
                    }else{
                        auxiliar=arreglo[j];
                        arreglo[j]=arreglo[k];
                        arreglo[k]=auxiliar;
                        j-=salto;//j=j-salto;
                    }
                }
            }
            salto=salto/2;
        }
        System.out.println("Arreglo Ordenado con Shell: ");
        mostrarArreglo(arreglo);
    }
    
    //Método intercalacion
    public void intercalacion(int [] arregloA,int [] arregloB){
        int i,j,k;
        int arregloC[]=new int[(arregloA.length + arregloB.length)];
        
        //REPETir mientras los arreglos A y B tengas elementosd que comparar
        for(i=j=k=0;i<arregloA.length && j<arregloB.length;k++){
            if(arregloA[i]<arregloB[j]){
                arregloC[k]=arregloA[i];
                i++;
            }else{
                arregloC[k]=arregloB[j];
                j++;
            }
        }
        //Para añadir a arreglo C los elementos del arreglo A sobreantes en caso de haberlos
        for(;i<arregloA.length;i++,k++){
            arregloC[k]=arregloA[i];
        }
        //Para añadir a arreglo C los elementos del arreglo B sobreantes en caso de haberlos
        for(;j<arregloB.length;j++,k++){
            arregloC[k]=arregloB[j];
        }
        System.out.println("Arreglo Ordenado con intercalacion");
        mostrarArreglo(arregloC);
    }
    
    //Método de MezclaDirecta
    public int [] mezclaDirecta(int [] arreglo){
        int i, j, k;
        if(arreglo.length>1){
            int nElementosIzq=arreglo.length/2;
            int nElementosDer=arreglo.length-nElementosIzq;
            int arregloIzq[]=new int[nElementosIzq];
            int arregloDer[]=new int[nElementosDer];
            //copiando los elementos de la parte primera al arregloIzq
            for(i=0;i<nElementosIzq;i++){
                arregloIzq[i]=arreglo[i];
            }
            //copiando los elementos de la parte segunda al arregloDer
            for(i=nElementosIzq;i<nElementosIzq+nElementosDer;i++){
                arregloDer[i - nElementosIzq] = arreglo[i];
            }
            //Recursividad
            arregloIzq=mezclaDirecta(arregloIzq);
            arregloDer=mezclaDirecta(arregloDer);
            i=0;
            j=0;
            k=0;
            while(arregloIzq.length!=j && arregloDer.length!=k){
                if(arregloIzq[j]<arregloDer[k]){
                    arreglo[i]=arregloIzq[j];
                    i++;
                    j++;
                }else{
                    arreglo[i]=arregloDer[k];
                    i++;
                    k++;
                }
            }
            //arreglo Final 
            while(arregloIzq.length!=j){
                arreglo[i]=arregloIzq[j];
                i++;
                j++;
            }
            while(arregloDer.length!=k){
                arreglo[i]=arregloDer[k];
                i++;
                k++;
            }
        }//fin del IF
        return arreglo;
    }
    
    //Mostrar los datos de un vector
    public void mostrarArreglo(int [] arreglo){
        int k;//variable local
        for(k=0;k<arreglo.length;k++){
            System.out.print("["+arreglo[k]+"]");
            
        }
        System.out.println();
    }
}    
